INSTRUCTION FOR HOW THIS APPLICATION WORKS
--------------------------------
(i) APPLICATION WILL LISTEN AT PORT = 3000.
(ii) BROWSE : http://localhost:3000/graphql
(iii) DATABASE: INVOICE
(iv) QUERIES ARE DESCRIBED BELOW : 
//-------------Shop Details---------------//
//function: shopsDetails

query{
  shopsDetails{
    x
  }
}
//x = id, name, address, contact, email (As per requirement)

//-------------Buyers Details---------------//
//function: buyersDetails
query{
  buyersDetails{
	x
  }
}
//x = id, name, contact, total, mark (As per requirement)

//-------------Items Details---------------//
//function: itemsDetails
query{
  itemsDetails{
    x
  }
}
//x = id, name, quantity, price, discount, GST, totalItemAmount

(v) Updates:
functions are :-
mutation{
  updateShop(){
    status
  }
}
mutation{
  updateBuyer(){
    status
  }
}
mutation{
  updateItem(){
    status
  }
}

(vi) Delete:
functions are :-
mutation{
  deleteShop(){
    status
  }
}
mutation{
  deleteBuyer(){
    status
  }
}
mutation{
  deleteItem(){
    status
  }
}

//---------------THE END---------------------//